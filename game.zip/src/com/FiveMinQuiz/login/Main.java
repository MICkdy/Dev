package com.FiveMinQuiz.login;

import com.FiveMinQuiz.InGame.QuizResult;

public class Main {
	public static void main(String[] args) {
		Login login = new Login();
//		login.start();
		
	}
}
