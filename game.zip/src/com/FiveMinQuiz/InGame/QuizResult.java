package com.FiveMinQuiz.InGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import com.FiveMinQuiz.DataBase.QuizDAO;
import com.FiveMinQuiz.DataBase.QuizVO;
import com.FiveMinQuiz.login.Login;

public class QuizResult extends JFrame implements ActionListener {
	QuizVO vo = new QuizVO();
	QuizDAO dao = new QuizDAO();
	JTextPane comm = new JTextPane();
	JButton next = new JButton(new ImageIcon(getClass().getResource("/Image/Result/Next.png")));
	ImageIcon pressedNext = new ImageIcon(getClass().getResource("/Image/Result/Click_Next.png"));
	ImageIcon pressedHome = new ImageIcon(getClass().getResource("/Image/Result/Click_home.png"));
	JButton Home = new JButton(new ImageIcon(getClass().getResource("/Image/Result/home.png")));
	JButton RankButton = new JButton(new ImageIcon(getClass().getResource("/Image/Result/RankingButton.png")));
	ImageIcon pressedRank = new ImageIcon(getClass().getResource("/Image/Result/Click_RankingButton.png"));
	Font font2 = new Font("����", Font.BOLD, 25);

	JLabel Right;
	JLabel RightAnswer = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/����.png")));

	JLabel Ranking = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/Ranking.png")));
	JLabel Rank1 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/01.png")));
	JLabel Rank2 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/02.png")));
	JLabel Rank3 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/03.png")));
	JLabel Rank4 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/04.png")));
	JLabel Rank5 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/05.png")));
	JLabel Rank6 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/06.png")));
	JLabel Rank7 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/07.png")));
	JLabel Rank8 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/08.png")));
	JLabel Rank9 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/09.png")));
	JLabel Rank10 = new JLabel(new ImageIcon(getClass().getResource("/Image/Result/10.png")));

	JLabel[] Rn = new JLabel[10];
	InGame pass = new InGame();
	int state;
	public void Result(String QuizComm, String answer, int NextCount) {
		state=0;
		next.setDefaultCapable(false);
		getContentPane().setLayout(null);
		setSize(900, 550);
		setUndecorated(true);
		setBackground(new Color(81, 80, 83, 220));
		setLocationRelativeTo(null);
		setUndecorated(true);
		if (NextCount < 12) {
			
			next.setBounds(790, 440, 100, 100);
			next.setPressedIcon(pressedNext);
			next.setBorderPainted(false);
			next.setContentAreaFilled(false);
			next.setFocusPainted(false);
			next.addActionListener(this);
			if (answer.equals("O")) {
				Right = new JLabel(new ImageIcon(getClass().getResource("/Image/InGame/O.png")));
				Right.setBounds(300, 110, 300, 300);
				Right.setOpaque(false);
			} else {
				Right = new JLabel(new ImageIcon(getClass().getResource("/Image/InGame/X.png")));
				Right.setBounds(300, 110, 300, 300);
				Right.setOpaque(false);
			}
			add(next);
		} else {
			RankButton.setBounds(790, 440, 100, 100);
			RankButton.setPressedIcon(pressedRank);
			RankButton.setBorderPainted(false);
			RankButton.setContentAreaFilled(false);
			RankButton.setFocusPainted(false);
			RankButton.addActionListener(this);
			if (answer.equals("O")) {
				Right = new JLabel(new ImageIcon(getClass().getResource("/Image/InGame/O.png")));
				Right.setBounds(300, 110, 300, 300);
				Right.setOpaque(false);
			} else {
				Right = new JLabel(new ImageIcon(getClass().getResource("/Image/InGame/X.png")));
				Right.setBounds(300, 110, 300, 300);
				Right.setOpaque(false);
			}
			add(RankButton);
		}
		RightAnswer.setBounds(300, 0, 300, 100);

		comm.setBounds(10, 420, 780, 540);
		comm.setOpaque(false);
		comm.setFont(font2);
		comm.setForeground(Color.white);
		comm.setText(QuizComm);
		comm.setEditable(false);

		
		add(comm);
		add(Right);
		add(RightAnswer);
		setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent a) {
		if (a.getSource() == next) {
			dispose();
		} else if(a.getSource()==RankButton) {
			dispose();
			FinalResult();
		} else if (a.getSource() == Home) {
			new Login().start();
			dispose();
		}
		
	}
	public void FinalResult() {
		JFrame Rp= new JFrame();
		Rp.getContentPane().setLayout(null);
		Rp.setSize(900, 550);
		Rp.setUndecorated(true);
		Rp.setBackground(new Color(81, 80, 83, 220));
		Rp.setLocationRelativeTo(null);
		Rp.setUndecorated(true);

		Ranking.setBounds(300, 0, 300, 100);

		Rank1.setBounds(10, 100, 50, 50);
		Rank2.setBounds(10, 170, 50, 50);
		Rank3.setBounds(10, 240, 50, 50);
		Rank4.setBounds(10, 310, 50, 50);
		Rank5.setBounds(10, 380, 50, 50);
		Rank6.setBounds(460, 100, 50, 50);
		Rank7.setBounds(460, 170, 50, 50);
		Rank8.setBounds(460, 240, 50, 50);
		Rank9.setBounds(460, 310, 50, 50);
		Rank10.setBounds(460, 380, 50, 50);

		Home.setBounds(790, 440, 100, 100);
		Home.setPressedIcon(pressedHome);
		Home.setBorderPainted(false);
		Home.setContentAreaFilled(false);
		Home.setFocusPainted(false);
		Home.addActionListener(this);

		List<QuizVO> WinRate = dao.resultInput();
		for (int i = 0; i < 10; i++) {
			vo = WinRate.get(i);
			Rn[i] = new JLabel(vo.getNicName() + " ��   " + vo.getScore() + " ��   " + vo.getGameDate());
			Rn[i].setFont(font2);
			Rn[i].setForeground(Color.white);
			if (i < 5) {
				Rn[i].setBounds(70, (((i + 1) * 100) - (i * 30)), 450, 50);
			} else {
				Rn[i].setBounds(520, (((i - 4) * 100) - ((i - 5) * 30)), 900, 50);
			}
			Rp.add(Rn[i]);
		}

		Rp.add(Ranking);
		Rp.add(Rank1);
		Rp.add(Rank2);
		Rp.add(Rank3);
		Rp.add(Rank4);
		Rp.add(Rank5);
		Rp.add(Rank6);
		Rp.add(Rank7);
		Rp.add(Rank8);
		Rp.add(Rank9);
		Rp.add(Rank10);
		Rp.add(Home);

		Rp.setVisible(true);
	}
}
