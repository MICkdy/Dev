package com.DataBase.Tabbbed;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import com.DataBase.QuizDAO;
import com.DataBase.QuizVO;

public class ShowTable extends JPanel {
	DefaultTableModel DTM;
	private JTable dataTable;
	JScrollPane pane;

	QuizDAO dao = new QuizDAO();

	public ShowTable() {
		String[] title = { "��ȣ", "����", "��", "�ؼ�" };
		DTM = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		}; // �� ���� �Ұ��� ����
		dao.qCont();
		for (int i = 0; i < dao.quizList.size(); i++) {
			QuizVO vo = dao.quizList.get(i);
			Vector QuizList = new Vector();
			QuizList.add(vo.getQuizNum());
			QuizList.add(vo.getQuizCont());
			QuizList.add(vo.getQuizAnsw());
			QuizList.add(vo.getQuizComm());

			DTM.addRow(QuizList);
		} // data ���
		dataTable = new JTable(DTM);
		dataTable.getTableHeader().setReorderingAllowed(false); // column ������ ����
		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = dataTable.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {
			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);

		} // �� ��� ����
		dataTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		dataTable.getColumnModel().getColumn(0).setPreferredWidth(50);
		dataTable.getColumnModel().getColumn(1).setPreferredWidth(185);
		dataTable.getColumnModel().getColumn(2).setPreferredWidth(25);
		dataTable.getColumnModel().getColumn(3).setPreferredWidth(185);
		dataTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					JTable t = (JTable) e.getSource(); // ������ ���� �� ��ȣ ���
					TableModel m = t.getModel();// ���̺��� �𵨰�ü �޾ƿ���
					int row = dataTable.getSelectedRow();
					int num = (int) m.getValueAt(row, 0);
					String content = (String) m.getValueAt(row, 1);
					String answer = (String) m.getValueAt(row, 2);
					String command = (String) m.getValueAt(row, 3);
					System.out.println(num+"\n"+content+"\n"+answer+"\n"+command);
					QuizVO selectQuiz = new QuizVO(num, content, answer, command);
					Modify mod = new Modify(selectQuiz);
					
				}
			}

		});
		pane = new JScrollPane(dataTable);
		
		add(pane);
	}

}
