package com.FiveMinQuiz.DataBase;

import java.sql.Date;

public class QuizVO {

	int quizNum;
	String quizCont;
	String quizAnsw;
	String quizComm;
	
	String nickName;
	int score;
	Date gameDate;

	public int getQuizNum() {
		return quizNum;
	}
	public void setQuizNum(int quizNum) {
		this.quizNum = quizNum;
	}
	public String getQuizCont() {
		return quizCont;
	}
	public void setQuizCont(String quizCont) {
		this.quizCont = quizCont;
	}
	public String getQuizAnsw() {
		return quizAnsw;
	}
	public void setQuizAnsw(String quizAnsw) {
		this.quizAnsw = quizAnsw;
	}
	public String getQuizComm() {
		return quizComm;
	}
	public void setQuizComm(String quizComm) {
		this.quizComm = quizComm;
	}
	
	
	public String getNicName() {
		return nickName;
	}
	public void setNicName(String nicName) {
		this.nickName = nicName;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Date getGameDate() {
		return gameDate;
	}
	public void setGameDate(Date gameDate) {
		this.gameDate = gameDate;
	}
}
