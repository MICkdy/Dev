package com.DataBase.Tabbbed;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.DataBase.QuizDAO;
import com.DataBase.QuizVO;

public class Modify extends JFrame{
	private QuizDAO dao = new QuizDAO();
	private JLabel qn= new JLabel("���� ��ȣ");
	private JLabel qc= new JLabel("���� ����");
	private JLabel qa= new JLabel("���� ��");
	private JLabel qcomm= new JLabel("�����ؼ�");
	
	private JTextField qnt;
	private JTextArea qct;
	
	private ButtonGroup radioGroup = new ButtonGroup();
	private JRadioButton qaO = new JRadioButton("O");
	private JRadioButton qaX=new JRadioButton("X");
	private JRadioButton non=new JRadioButton();
	
	private JTextArea qcommt;
	
	private JButton Modify = new JButton("Modify");
	private JButton Delete = new JButton("Delete");
	private JButton Back = new JButton("Back");
	
	public Modify(QuizVO selectQuiz) {
		
		setTitle(selectQuiz.getQuizCont());
		setLayout(null);
		setSize(500,600);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		qnt = new JTextField(Integer.toString(selectQuiz.getQuizNum()));
		qct = new JTextArea(selectQuiz.getQuizCont());
		if (selectQuiz.getQuizAnsw().equals("O")) {
			qaO.setSelected(true);
		}else if(selectQuiz.getQuizAnsw().equals("X")){
			qaX.setSelected(true);
		}else {
			non.setSelected(true);
		}
		qcommt= new JTextArea(selectQuiz.getQuizComm());
		
		qn.setBounds(30, 30, 100, 30);
		qc.setBounds(30, 65, 100, 30);
		qa.setBounds(30, 170, 50, 30);
		qcomm.setBounds(30, 205, 100, 30);
		
		qnt.setBounds(140, 30, 100, 30);
		qct.setBounds(140, 65, 330, 100);
		qaO.setBounds(220, 170, 50, 30);
		qaX.setBounds(330, 170, 50, 30);
		qcommt.setBounds(140, 205, 330, 300);
		Back.setBounds(50, 515, 100, 30);
		Back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clear();
				dispose();
			}
		});
		Modify.setBounds(200, 515, 100, 30);
		Modify.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("Modify")) {
					String answer;
					int num = Integer.parseInt(qnt.getText());
					int originNum = selectQuiz.getQuizNum();
					String content = qct.getText();
					if(qaO.isSelected()==true) {
						 answer = qaO.getText();
					}else {
						 answer = qaX.getText();
					}
					String command = qcommt.getText();
					
					JOptionPane.showMessageDialog(null, "��� �����Ǿ����ϴ�.");
					System.out.println(num+"\n"+content+"\n"+answer+"\n"+command+"\n"+originNum);
					dao.Update(num, content, answer,command, originNum);
					clear();
					dispose();
				}
			}
		});
		Delete.setBounds(350, 515, 100, 30);
		Delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("Delete")) {
					int num = Integer.parseInt(qnt.getText());
					JOptionPane.showMessageDialog(null, "��� �����Ǿ����ϴ�.");
					dao.delete(num);
					clear();
					dispose();
				}
			}
		});
		add(qn);
		add(qc);
		add(qa);
		add(qcomm);
		add(qnt);
		add(qct);
		radioGroup.add(qaO);
		radioGroup.add(qaX);
		radioGroup.add(non);
		add(qaO);
		add(qaX);
		add(qcommt);
		add(Back);
		add(Modify);
		add(Delete);
		setVisible(true);
	}
	public void clear() {
		qnt.setText("");
		qct.setText("");
		qnt.setText("");
		non.setSelected(true);
		qcommt.setText("");
	}
}
