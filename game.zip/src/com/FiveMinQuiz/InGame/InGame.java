package com.FiveMinQuiz.InGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextPane;

import com.FiveMinQuiz.DataBase.QuizDAO;
import com.FiveMinQuiz.DataBase.QuizVO;
import com.FiveMinQuiz.login.Login;

public class InGame extends JFrame implements ActionListener {
	QuizVO vo = new QuizVO();
	QuizDAO dao = new QuizDAO();
	JLabel bg = new JLabel();
	Random rd = new Random();
	JTextPane Quiz = new JTextPane();
	JButton ASO = new JButton(new ImageIcon(getClass().getResource("/Image/InGame/O.png")));
	JButton ASX = new JButton(new ImageIcon(getClass().getResource("/Image/InGame/X.png")));
	JButton Pre = new JButton(new ImageIcon(getClass().getResource("/Image/InGame/pre.png")));
	ImageIcon pressedO = new ImageIcon(getClass().getResource("/Image/InGame/Click_O.png"));
	ImageIcon pressedX = new ImageIcon(getClass().getResource("/Image/InGame/Click_X.png"));
	ImageIcon pressedExit = new ImageIcon(getClass().getResource("/Image/InGame/Click_Pre.png"));
	Font font = new Font("����", Font.BOLD, 60);
	int score;
	int Count = 1;
	int NextCount;
	private String Nic;

	public void IG(String name) {
		Nic = name;
		dao.qCont();
		int n = (rd.nextInt(29) + 1); // �������� ���ڸ� �̾�
		vo = dao.quizList.get(n);
		Quiz.setText("Q_" + Count + ")" + vo.getQuizCont());
		Quiz.setEditable(false);

		// �ʱ� ���� ������ ����
		setTitle("�̰ž�?");
		getContentPane().setLayout(null);
		setSize(1200, 750);// (feat.����ȣ)
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setUndecorated(true);

		bg.setIcon(new ImageIcon(getClass().getResource("/Image/InGame/ingamebg.png")));

		bg.setBounds(0, 0, 1200, 750);
		Quiz.setBounds(80, 60, 970, 290);
		ASO.setBounds(250, 350, 300, 300);
		ASX.setBounds(700, 350, 300, 300);
		Pre.setBounds(20, 625, 225, 77);

		Quiz.setOpaque(false);
		Quiz.setFont(font);
		Quiz.setForeground(Color.white);

		ASO.setPressedIcon(pressedO);
		ASO.setBorderPainted(false);
		ASO.setContentAreaFilled(false);
		ASO.setFocusPainted(false);
		ASO.addActionListener(this);

		ASX.setPressedIcon(pressedX);
		ASX.setBorderPainted(false);
		ASX.setContentAreaFilled(false);
		ASX.setFocusPainted(false);
		ASX.addActionListener(this);

		Pre.setPressedIcon(pressedExit);
		Pre.setBorderPainted(false);
		Pre.setContentAreaFilled(false);
		Pre.setFocusPainted(false);
		Pre.addActionListener(this);

		add(Quiz);
		add(ASO);
		add(ASX);
		add(Pre);
		add(bg);
		// ������ ���
		setVisible(true);

	}// start

	@Override
	public void actionPerformed(ActionEvent a) {
		String answer = vo.getQuizAnsw();
		String action = null;
		++Count;
		if (a.getSource() == Pre) {
			new Login().start();
			dispose();
		} else if (a.getSource() == ASO) {
			action = "O";
			NextCount = Count + 1;
			if (Count < 11) {
				new QuizResult().Result(vo.getQuizComm(), answer, NextCount);// �ؼ�
				if (NextCount < 12) {
					int n = (rd.nextInt(29) + 1); // �������� ���ڸ� �̾�
					vo = dao.quizList.get(n);
					Quiz.setText("Q_" + Count + ")" + vo.getQuizCont());
					Quiz.setEditable(false);
					if (action.equals(answer)) {
						score++;
					}
				}
			} else if (NextCount == 12) {
				String name = this.Nic;
				dao.insertPlayer(name, score);
				new QuizResult().Result(vo.getQuizComm(), answer, NextCount);// �ؼ�
			}
		} else if (a.getSource() == ASX) {
			action = "X";
			NextCount = Count + 1;
			if (Count < 11) {
				new QuizResult().Result(vo.getQuizComm(), answer, NextCount);// �ؼ�
				if (NextCount < 12) {
					int n = (rd.nextInt(29) + 1); // �������� ���ڸ� �̾�
					vo = dao.quizList.get(n);
					Quiz.setText("Q_" + Count + ")" + vo.getQuizCont());
					Quiz.setEditable(false);
					if (action.equals(answer)) {
						score++;
					}
				}
			} else if (NextCount == 12) {
				String name = this.Nic;
				dao.insertPlayer(name, score);
				new QuizResult().Result(vo.getQuizComm(), answer, NextCount);// �ؼ�
			}
		}
	}

} // Class
