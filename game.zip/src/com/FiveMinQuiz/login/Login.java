package com.FiveMinQuiz.login;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.FiveMinQuiz.InGame.InGame;
import com.FiveMinQuiz.InGame.QuizResult;

public class Login extends JFrame implements ActionListener {
	JLabel bg = new JLabel();
	private JLabel Nicname = new JLabel(new ImageIcon(getClass().getResource("/Image/login/NickName.png")));
	private JButton Jbtn = new JButton(new ImageIcon(getClass().getResource("/Image/login/Lbutton.png")));
	private JButton exit = new JButton(new ImageIcon(getClass().getResource("/Image/login/exit.png")));
	ImageIcon pressedExit = new ImageIcon(getClass().getResource("/Image/login/Click_exit.png"));
	ImageIcon pressedLogin = new ImageIcon(getClass().getResource("/Image/login/Click_Lbutton.png"));
	public JTextField NicInput = new JTextField();
	private Font font = new Font("��ü�� �ƹ�����ü", Font.BOLD, 50);

	public void start() {
		// �ʱ� ���� ������ ����
		setTitle("�̰ž�?");
		getContentPane().setLayout(null);
		setSize(1200, 750);// (feat.����ȣ)
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setUndecorated(true);

		bg.setIcon(new ImageIcon(getClass().getResource("/Image/login/background.png")));

		bg.setBounds(0, 0, 1200, 750);

		Jbtn.setBounds(660, 540, 160, 150);
		Jbtn.setBorderPainted(false);
		Jbtn.setContentAreaFilled(false);
		Jbtn.setFocusPainted(false);
		Jbtn.addActionListener(this);
		Jbtn.setPressedIcon(pressedLogin);

		exit.setBounds(430, 670, 220, 60);
		exit.setBorderPainted(false);
		exit.setContentAreaFilled(false);
		exit.setFocusPainted(false);
		exit.addActionListener(this);
		exit.setPressedIcon(pressedExit);

		Nicname.setBounds(430, 540, 220, 60);

		NicInput.setFont(font);
		NicInput.setOpaque(false);
		NicInput.setForeground(Color.white);
		NicInput.setBounds(430, 600, 220, 60);

		add(Nicname);
		add(NicInput);
		add(Jbtn);
		add(exit);
		add(bg);
		// ������ ���
		setVisible(true);

	}// start

	@Override
	public void actionPerformed(ActionEvent a) {
		if (a.getSource() == Jbtn) {
			String name = NicInput.getText();
			if (name.length() == 0) {
				JOptionPane.showMessageDialog(bg,"�г����� �Է����ּ���.");
			}else if (name.length() != 0){
				new InGame().IG(name);
				dispose();
			}
		} else {
			System.exit(0);
		}
	} // ActionPerformed

} // Class
