package com.FiveMinQuiz.DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuizDAO {

	public List<QuizVO> quizList = new ArrayList<>();
	public List<QuizVO> winRate = new ArrayList<>();

	Connection conn;
	Statement stmt;
	ResultSet rs;

	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "scott";
	String pwd = "tiger";

	public List<QuizVO> qCont() {
		try {
			connDB();

			String query = "select * from quiz";
			rs = stmt.executeQuery(query);

			while (rs.next()) {

				QuizVO vo = new QuizVO();

				vo.setQuizNum(rs.getInt("quizNum"));
				vo.setQuizCont(rs.getString("quizCont"));
				vo.setQuizAnsw(rs.getString("quizAnsw"));
				vo.setQuizComm(rs.getString("quizComm"));

				quizList.add(vo);
			}
			rs.close();
			conn.close();
			stmt.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return quizList;
	}

	public void insertPlayer(String nickName, int score) {
		try {
			connDB();
			String query = "insert into winRate(nickName, score) values('" + nickName + "', '" + score + "')";
			stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public List<QuizVO> resultInput() {
		try {
			connDB();

			String query2 = "select * from winRate order by score desc";
			rs = stmt.executeQuery(query2);

			while (rs.next()) {

				QuizVO vo = new QuizVO();

				vo.setNicName(rs.getString("nickName"));
				vo.setScore(rs.getInt("score"));
				vo.setGameDate(rs.getDate("gameDate"));

				winRate.add(vo);
			}
			rs.close();
			conn.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return winRate;
	}

	private void connDB() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
			stmt = conn.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // connDB

}
