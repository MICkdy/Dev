package com.DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JOptionPane;

public class QuizDAO {

	public List<QuizVO> quizList = new ArrayList<QuizVO>();
	public List<QuizVO> winRate = new ArrayList<>();

	Connection conn;
	Statement stmt;
	PreparedStatement ps;
	ResultSet rs;

	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "scott";
	String pwd = "tiger";

	public void connDB() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
			stmt = conn.createStatement();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "�����ͺ��̽��� ������ �����߽��ϴ�.");
		}
	} // connDB

	public List<QuizVO> qCont() {
		try {
			connDB();
			String query = "select * from quiz";
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				QuizVO vo = new QuizVO();
				vo.setQuizNum(rs.getInt("quizNum"));
				vo.setQuizCont(rs.getString("quizCont"));
				vo.setQuizAnsw(rs.getString("quizAnsw"));
				vo.setQuizComm(rs.getString("quizComm"));
				quizList.add(vo);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			dbClose();
		}
		return quizList;
	}

	public void Insert(int num, String content, String answer, String command) {
		try {
			connDB();
			String query = "insert into quiz(quizNum,quizCont,quizAnsw,quizComm) values(" + num + ", '" + content
					+ "', '" + answer + "', '" + command + "')";
			rs = stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			dbClose();
		}
	}

	public void Update(int num, String content, String answer, String command, int originNum) {
		try {
			connDB();
			String query = "update quiz set quizNum = "+num;
			query += ", quizCont = '"+content;
			query += "', quizAnsw = '"+answer;
			query += "', quizComm = '"+command;
			query += "' where quizNum="+originNum;
			System.out.println(query);
			ps = conn.prepareStatement(query);
			rs = stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			dbClose();
		}
	}
	public void delete(int num) {
		try {
			connDB();
			String query = "delete from quiz where quizNum = "+num;
			System.out.println(query);
			ps = conn.prepareStatement(query);
			System.out.println(num);
			rs = stmt.executeQuery(query);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			dbClose();
		}
	}

	public void dbClose() {
		try {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (ps != null)
				ps.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
