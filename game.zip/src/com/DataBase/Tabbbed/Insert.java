package com.DataBase.Tabbbed;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.DataBase.QuizDAO;

public class Insert extends JPanel{
	private QuizDAO dao = new QuizDAO();
	private JLabel qn= new JLabel("���� ��ȣ");
	private JLabel qc= new JLabel("���� ����");
	private JLabel qa= new JLabel("���� ��");
	private JLabel qcomm= new JLabel("�����ؼ�");
	
	private JTextField qnt= new JTextField();
	private JTextArea qct= new JTextArea();
	
	private ButtonGroup radioGroup = new ButtonGroup();
	private JRadioButton qaO = new JRadioButton("O");
	private JRadioButton qaX=new JRadioButton("X");
	private JRadioButton non=new JRadioButton();
	
	private JTextArea qcommt= new JTextArea();
	
	private JButton Insert = new JButton("Insert");
	
	public Insert() {
		
		setLayout(null);
		
		qn.setBounds(30, 30, 100, 30);
		qc.setBounds(30, 65, 100, 30);
		qa.setBounds(30, 170, 50, 30);
		qcomm.setBounds(30, 205, 100, 30);
		
		qnt.setBounds(140, 30, 100, 30);
		qct.setBounds(140, 65, 330, 100);
		qaO.setBounds(220, 170, 50, 30);
		qaX.setBounds(330, 170, 50, 30);
		qcommt.setBounds(140, 205, 330, 300);
		
		Insert.setBounds(195, 515, 100, 30);
		Insert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("Insert")) {
					String answer;
					int num = Integer.parseInt(qnt.getText());
					String content = qct.getText();
					if(qaO.isSelected()==true) {
						 answer = qaO.getText();
					}else {
						 answer = qaX.getText();
					}
					String command = qcommt.getText();
					
					JOptionPane.showMessageDialog(null, "���ο� ��� ���ŵǾ����ϴ�.");
					dao.Insert(num, content, answer,command);
					clear();
				}
			}
		});
		
		add(qn);
		add(qc);
		add(qa);
		add(qcomm);
		add(qnt);
		add(qct);
		radioGroup.add(qaO);
		radioGroup.add(qaX);
		radioGroup.add(non);
		add(qaO);
		add(qaX);
		add(qcommt);
		add(Insert);
	}
	public void clear() {
		qnt.setText("");
		qct.setText("");
		qnt.setText("");
		non.setSelected(true);
		qcommt.setText("");
	}
}
