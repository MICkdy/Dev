package com.DataBase;

import java.sql.Date;

public class QuizVO {

	int quizNum;
	String quizCont;
	String quizAnsw;
	String quizComm;
	
	public QuizVO() {
	}
	public QuizVO(int quizNum, String quizCont, String quizAnsw, String quizComm) {
		this.quizNum = quizNum;
		this.quizCont = quizCont;
		this.quizAnsw = quizAnsw;
		this.quizComm = quizComm;
	}
	public int getQuizNum() {
		return quizNum;
	}
	public void setQuizNum(int quizNum) {
		this.quizNum = quizNum;
	}
	public String getQuizCont() {
		return quizCont;
	}
	public void setQuizCont(String quizCont) {
		this.quizCont = quizCont;
	}
	public String getQuizAnsw() {
		return quizAnsw;
	}
	public void setQuizAnsw(String quizAnsw) {
		this.quizAnsw = quizAnsw;
	}
	public String getQuizComm() {
		return quizComm;
	}
	public void setQuizComm(String quizComm) {
		this.quizComm = quizComm;
	}
	
}

