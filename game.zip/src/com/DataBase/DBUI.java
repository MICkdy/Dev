package com.DataBase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.DataBase.Tabbbed.Insert;
import com.DataBase.Tabbbed.Modify;
import com.DataBase.Tabbbed.ShowTable;

public class DBUI extends JFrame{
	private static final long serialVersionUID = 1L;
	JMenuBar menuBar = new JMenuBar();
	JMenu File = new JMenu("File");
	JMenu Help = new JMenu("Help");
	JTabbedPane TabLIst = new JTabbedPane(JTabbedPane.TOP);
	JTextField test = new JTextField();
	ShowTable St = new ShowTable();
	private JButton Refresh = new JButton("Refresh");
	private JButton Exit = new JButton("Exit");
	public void dbUI() {
		setTitle("DB Managerment");
		setLayout(null);
		setSize(500,700);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		Refresh.setBounds(260, 30, 100, 30);
		Refresh.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				}
		});
		Exit.setBounds(380, 30, 100, 30);
		Exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		menuBar.setBounds(0, 0, 500, 20);
		TabLIst.setBounds(5, 45, 485, 645);
		
		add(menuBar);
		menuBar.add(File);
		menuBar.add(Help);
		
		add(Refresh);
		add(Exit);
		
		add(TabLIst);
		
		TabLIst.addTab("Show Table", new ShowTable());
		TabLIst.addTab("Insert", new Insert());
		
		setVisible(true);
	}
}

	