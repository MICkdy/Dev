package com.DataBase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;

	JPanel contentPane;
	JLabel Title = new JLabel(new ImageIcon(getClass().getResource("/Image/image/title.png")));
	JLabel ID = new JLabel("ID");
	JLabel PassWord = new JLabel("PassWord");
	JTextField IDInput = new JTextField();;
	JPasswordField PassInput = new JPasswordField();
	JButton LoginButton = new JButton("Login");
	JButton Exit = new JButton("Exit");

	public void login() {
		setTitle("DB Managerment");
		getContentPane().setLayout(null);
		setSize(410, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		Title.setBounds(0, 0, 400, 300);
		ID.setBounds(55, 430, 100, 30);
		PassWord.setBounds(55, 470, 100, 30);
		IDInput.setBounds(125, 430, 100, 30);
		PassInput.setBounds(125, 470, 100, 30);
		LoginButton.setBounds(250, 430, 100, 30);
		Exit.setBounds(250, 470, 100, 30);

		PassInput.setEchoChar('*');

		LoginButton.addActionListener(this);
		Exit.addActionListener(this);

		getContentPane().add(Title);
		getContentPane().add(ID);
		getContentPane().add(PassWord);
		getContentPane().add(IDInput);
		getContentPane().add(PassInput);
		getContentPane().add(LoginButton);
		getContentPane().add(Exit);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent a) {
		String id = IDInput.getText();
		String pass = new String(PassInput.getPassword());
		if (a.getSource() == LoginButton) {
			if ((id.length() == 0) || (pass.length() == 0)) {
				JOptionPane.showMessageDialog(null, "���̵�� ��й�ȣ�� �Է����ּ���");
			} else {
				new DBUI().dbUI();
				dispose();
			}
		} else {
			System.exit(0);
		}
	}
}
